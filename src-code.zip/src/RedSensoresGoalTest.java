package redsensores;

import aima.search.framework.GoalTest;

public class RedSensoresGoalTest implements GoalTest {

    public boolean isGoalState(Object state) {
        return false;
    }
    
}